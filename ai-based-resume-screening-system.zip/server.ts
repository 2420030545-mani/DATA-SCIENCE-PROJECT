import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const screeningResponseSchema = {
  type: Type.OBJECT,
  properties: {
    candidateName: { type: Type.STRING, description: "Full name of candidate or 'Anonymous Candidate' if anonymized" },
    candidateEmail: { type: Type.STRING, description: "Candidate contact email or N/A" },
    candidatePhone: { type: Type.STRING, description: "Candidate phone or N/A" },
    candidateLocation: { type: Type.STRING, description: "Location or N/A" },
    currentRole: { type: Type.STRING, description: "Current or most recent job title" },
    totalExperienceYears: { type: Type.NUMBER, description: "Estimated total years of relevant experience" },
    educationSummary: { type: Type.STRING, description: "Degree, university, or highest education achieved" },
    matchScore: { type: Type.NUMBER, description: "Overall alignment score from 0 to 100" },
    scoreBreakdown: {
      type: Type.OBJECT,
      properties: {
        technicalSkills: { type: Type.NUMBER, description: "0-100 score on hard skills" },
        relevantExperience: { type: Type.NUMBER, description: "0-100 score on industry and task experience" },
        educationCertifications: { type: Type.NUMBER, description: "0-100 score on education & credentials" },
        domainAlignment: { type: Type.NUMBER, description: "0-100 score on industry domain relevance" },
        softSkillsLeadership: { type: Type.NUMBER, description: "0-100 score on communication, teamwork, leadership" },
      },
      required: ["technicalSkills", "relevantExperience", "educationCertifications", "domainAlignment", "softSkillsLeadership"],
    },
    recommendation: {
      type: Type.STRING,
      description: "One of: Strong Hire, Hire, Consider, Low Match, Reject",
    },
    executiveSummary: { type: Type.STRING, description: "Concise 2-3 sentence hiring manager verdict" },
    keyStrengths: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Top 3-5 specific strengths directly aligned with the job description",
    },
    potentialGaps: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Missing or unproven qualifications based on the job description",
    },
    matchedSkills: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Technologies, tools, and methodologies explicitly mentioned in both resume and JD",
    },
    missingCrucialSkills: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Mandatory JD requirements absent or weak in the resume",
    },
    niceToHaveSkillsPresent: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Bonus skills candidate brings that benefit the role",
    },
    redFlagsOrConcerns: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Tenure gaps, inconsistencies, or lack of critical prerequisite indicators",
    },
    customizedInterviewQuestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING, description: "Targeted technical or behavioral question probing this candidate's specific background" },
          reason: { type: Type.STRING, description: "Why this question is critical for this candidate" },
          expectedAnswerTheme: { type: Type.STRING, description: "What a senior evaluator should look for in their answer" },
        },
        required: ["question", "reason", "expectedAnswerTheme"],
      },
    },
    recommendedSeniorityLevel: { type: Type.STRING, description: "e.g., Junior, Mid-Level, Senior, Lead/Staff, Principal" },
    applicantFeedbackTips: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Constructive advice on how the candidate can improve their resume for this type of role",
    },
  },
  required: [
    "candidateName",
    "matchScore",
    "scoreBreakdown",
    "recommendation",
    "executiveSummary",
    "keyStrengths",
    "potentialGaps",
    "matchedSkills",
    "missingCrucialSkills",
    "customizedInterviewQuestions",
  ],
};

// Health Check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    apiKeyConfigured: Boolean(process.env.GEMINI_API_KEY),
    model: 'gemini-3.8-flash',
  });
});

// Single Resume Screening
app.post('/api/screen-single', async (req: Request, res: Response) => {
  try {
    const {
      jobTitle,
      jobDescription,
      resumeText,
      fileBase64,
      mimeType,
      fileName,
      biasShield = false,
      strictnessLevel = 'balanced', // 'lenient' | 'balanced' | 'strict'
    } = req.body;

    if (!jobDescription || (!resumeText && !fileBase64)) {
      res.status(400).json({ error: 'Job description and resume content (text or file) are required.' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please ensure the key is present in your environment secrets.',
      });
      return;
    }

    const systemInstruction = `You are an elite, objective Senior Technical Talent Screening Officer and ATS (Applicant Tracking System) Evaluation Intelligence Engine.
Your task is to thoroughly analyze candidate resumes against target job descriptions with precision, deep semantic understanding, and actionable insights.

Evaluation Guidelines:
1. Scoring Criteria (0-100 total):
   - Strictness level requested: ${strictnessLevel}.
   - In 'strict' mode, penalize heavily for missing mandatory tech stack requirements.
   - In 'balanced' mode, evaluate both direct keyword matches and equivalent transferable expertise.
   - In 'lenient' mode, credit adjacent experience and high potential.
2. Fairness & Bias Shield:
   - If Bias Shield is active (${biasShield ? 'TRUE' : 'FALSE'}), do NOT factor in or evaluate candidate name, gender indicators, age, photo, marital status, or graduation dates. Treat candidateName as "Candidate [Initials/Code]" if anonymization is requested.
3. Realistic, Nuanced Scoring:
   - Do NOT just assign 90+ to everyone. A typical distribution:
     - 85-100: Exceptional fit, hits all core requirements + depth.
     - 70-84: Strong candidate, minor gaps easily trainable.
     - 50-69: Moderate fit, missing 1-2 key requirements or junior for the role.
     - Below 50: Poor alignment or fundamentally different domain.
4. Output must be strictly valid JSON conforming to the requested schema.`;

    const promptText = `
JOB ROLE TITLE: ${jobTitle || 'Unspecified Role'}
TARGET JOB DESCRIPTION & REQUIREMENTS:
${jobDescription}

${biasShield ? 'NOTE: Bias Shield is ENABLED. Focus strictly on demonstrable skills, work achievements, and role competencies.' : ''}

Evaluate the candidate resume provided below against this exact Job Description.
${resumeText ? `\n--- RESUME TEXT ---\n${resumeText}\n--- END RESUME ---` : `[Resume attached as file: ${fileName || 'uploaded_document'}]`}
`;

    const parts: any[] = [];
    if (fileBase64) {
      const cleanBase64 = fileBase64.replace(/^data:[^;]+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: mimeType || 'application/pdf',
          data: cleanBase64,
        },
      });
    }
    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: parts.length === 1 ? parts[0].text : { parts },
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: screeningResponseSchema as any,
      },
    });

    const rawText = response.text || '{}';
    let parsedResult;
    try {
      parsedResult = JSON.parse(rawText);
    } catch {
      // Fallback clean markdown block if model wrapped in ```json
      const cleaned = rawText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      parsedResult = JSON.parse(cleaned);
    }

    res.json({
      success: true,
      data: parsedResult,
    });
  } catch (error: any) {
    console.error('Screening API Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to screen resume via Gemini API.',
    });
  }
});

// Generate Job Description endpoint
app.post('/api/generate-jd', async (req: Request, res: Response) => {
  try {
    const { title, seniority, keySkills, industry, companyContext } = req.body;

    if (!title) {
      res.status(400).json({ error: 'Job title is required.' });
      return;
    }

    const jdSchema = {
      type: Type.OBJECT,
      properties: {
        jobTitle: { type: Type.STRING },
        seniorityLevel: { type: Type.STRING },
        department: { type: Type.STRING },
        summary: { type: Type.STRING },
        keyResponsibilities: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        mustHaveSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        niceToHaveSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        minimumExperienceYears: { type: Type.NUMBER },
        screeningRubric: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              criteria: { type: Type.STRING },
              weightPercentage: { type: Type.NUMBER },
              guidanceForRecruiter: { type: Type.STRING },
            },
            required: ["criteria", "weightPercentage", "guidanceForRecruiter"],
          },
        },
        fullFormattedMarkdown: { type: Type.STRING },
      },
      required: ["jobTitle", "summary", "keyResponsibilities", "mustHaveSkills", "screeningRubric", "fullFormattedMarkdown"],
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Generate a high-quality, inclusive, modern, ATS-optimized Job Description for:
Role: ${title}
Seniority: ${seniority || 'Mid-Senior'}
Industry / Domain: ${industry || 'Technology'}
Core Tech / Skills specified: ${keySkills || 'Standard industry stack for this role'}
Company / Team notes: ${companyContext || 'High-growth innovative team'}`,
      config: {
        systemInstruction: "You are an expert Chief People Officer and Tech Talent Architect. Create realistic, rigorous, and inclusive job descriptions that attract top talent without unnecessary gatekeeping.",
        responseMimeType: 'application/json',
        responseSchema: jdSchema as any,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Generate JD Error:', error);
    res.status(500).json({ error: error?.message || 'Failed to generate job description.' });
  }
});

// Resume Bullet Improver
app.post('/api/optimize-bullet', async (req: Request, res: Response) => {
  try {
    const { originalBullet, targetRole, keyTechnology } = req.body;
    if (!originalBullet) {
      res.status(400).json({ error: 'Original bullet point is required.' });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Given the following resume bullet point: "${originalBullet}"
Target Role: ${targetRole || 'Software Engineer'}
Target Tech: ${keyTechnology || 'General Tech'}

Provide 3 enhanced, high-impact variations following the Google XYZ formula: "Accomplished [X] as measured by [Y], by doing [Z]" with strong action verbs and quantified impact metrics.
Return as JSON array of strings.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            improvedVariations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            explanationOfChanges: { type: Type.STRING },
          },
          required: ["improvedVariations", "explanationOfChanges"],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, data: parsed });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || 'Failed to optimize bullet point.' });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Error starting server:', err);
  process.exit(1);
});
