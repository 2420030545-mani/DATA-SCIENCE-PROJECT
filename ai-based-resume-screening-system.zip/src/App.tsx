import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ScreeningStudio } from './components/ScreeningStudio';
import { CandidateLeaderboard } from './components/CandidateLeaderboard';
import { CandidateDossierModal } from './components/CandidateDossierModal';
import { CompareModal } from './components/CompareModal';
import { JobArchitectModal } from './components/JobArchitectModal';
import { BulletOptimizerModal } from './components/BulletOptimizerModal';
import { CandidateItem } from './types';
import { DEFAULT_JOB_TEMPLATES, SAMPLE_CANDIDATES } from './data/mockTemplates';
import { Sparkles, Shield, Cpu, Database, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [candidates, setCandidates] = useState<CandidateItem[]>(SAMPLE_CANDIDATES);
  const [activeTab, setActiveTab] = useState<'studio' | 'leaderboard' | 'jd-architect' | 'bullet-polisher'>('studio');
  const [biasShield, setBiasShield] = useState<boolean>(false);
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateItem | null>(null);
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);
  const [showCompareModal, setShowCompareModal] = useState<boolean>(false);
  const [apiKeyActive, setApiKeyActive] = useState<boolean>(true);

  const [activeJob, setActiveJob] = useState({
    title: DEFAULT_JOB_TEMPLATES[0].title,
    description: DEFAULT_JOB_TEMPLATES[0].description,
    templateId: DEFAULT_JOB_TEMPLATES[0].id,
  });

  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.apiKeyConfigured !== undefined) {
          setApiKeyActive(data.apiKeyConfigured);
        }
      })
      .catch(() => {
        // Ignore health check failure gracefully
      });
  }, []);

  const evaluatedCount = candidates.filter(c => c.status === 'completed' && c.result).length;

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-white">
      {/* Navbar with header matching reference image */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        candidateCount={candidates.length}
        evaluatedCount={evaluatedCount}
        biasShield={biasShield}
        setBiasShield={setBiasShield}
        apiKeyActive={apiKeyActive}
        onOpenNewUpload={() => {
          setActiveTab('studio');
        }}
      />

      {/* Main Tab Panels */}
      <main className="flex-1 pb-16">
        {activeTab === 'studio' && (
          <ScreeningStudio
            candidates={candidates}
            setCandidates={setCandidates}
            activeJob={activeJob}
            setActiveJob={setActiveJob}
            biasShield={biasShield}
            setBiasShield={setBiasShield}
            onSelectCandidate={(cand) => setSelectedCandidate(cand)}
            onNavigateToLeaderboard={() => setActiveTab('leaderboard')}
          />
        )}

        {activeTab === 'leaderboard' && (
          <CandidateLeaderboard
            candidates={candidates}
            biasShield={biasShield}
            onSelectCandidate={(cand) => setSelectedCandidate(cand)}
            selectedForCompare={selectedForCompare}
            setSelectedForCompare={setSelectedForCompare}
            onOpenCompare={() => setShowCompareModal(true)}
          />
        )}

        {activeTab === 'jd-architect' && (
          <JobArchitectModal
            onApplyToStudio={(newJob) => {
              setActiveJob(newJob);
              setActiveTab('studio');
            }}
          />
        )}

        {activeTab === 'bullet-polisher' && <BulletOptimizerModal />}
      </main>

      {/* Candidate Dossier Detail Modal */}
      {selectedCandidate && (
        <CandidateDossierModal
          candidate={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
          biasShield={biasShield}
        />
      )}

      {/* Side-by-Side Comparison Modal */}
      {showCompareModal && (
        <CompareModal
          candidates={candidates}
          selectedIds={selectedForCompare}
          onClose={() => setShowCompareModal(false)}
          biasShield={biasShield}
        />
      )}

      {/* System Footer */}
      <footer className="border-t border-slate-900 bg-black/90 py-6 px-4 sm:px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-cinzel uppercase font-bold text-white tracking-wider">
              AI-BASED RESUME SCREENING SYSTEM
            </span>
            <span>•</span>
            <span className="text-slate-400">Enterprise Talent Intelligence</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono-code text-slate-400">
            <span className="flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>Gemini 3.8 Flash Multimodal</span>
            </span>
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Fairness & Bias Shield</span>
            </span>
            <span className="flex items-center gap-1">
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              <span>ATS Semantic Parser</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
