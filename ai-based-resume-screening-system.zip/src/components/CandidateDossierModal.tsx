import React from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  Award, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  GraduationCap, 
  Printer, 
  Share2, 
  Sparkles,
  TrendingUp,
  FileText,
  Copy,
  Check
} from 'lucide-react';
import { CandidateItem } from '../types';

interface CandidateDossierModalProps {
  candidate: CandidateItem | null;
  onClose: () => void;
  biasShield: boolean;
}

export const CandidateDossierModal: React.FC<CandidateDossierModalProps> = ({
  candidate,
  onClose,
  biasShield,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!candidate || !candidate.result) return null;

  const res = candidate.result;
  const displayName = biasShield ? res.candidateName : candidate.name;

  let recColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50';
  if (res.recommendation === 'Consider') recColor = 'bg-amber-500/20 text-amber-300 border-amber-500/50';
  else if (res.recommendation === 'Low Match' || res.recommendation === 'Reject') recColor = 'bg-rose-500/20 text-rose-300 border-rose-500/50';
  else if (res.recommendation === 'Hire') recColor = 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50';

  const handlePrint = () => {
    window.print();
  };

  const handleCopyFeedback = () => {
    if (!res.applicantFeedbackTips) return;
    const text = `Candidate Feedback for ${displayName}:\n\n` + 
      res.applicantFeedbackTips.map(t => `• ${t}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Header Bar */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/80 flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold text-lg font-mono-code shadow-md">
              {displayName.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="text-lg font-bold text-white font-cinzel">{displayName}</h3>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase font-mono-code border ${recColor}`}>
                  {res.recommendation}
                </span>
                {res.recommendedSeniorityLevel && (
                  <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono-code border border-slate-700">
                    Level: {res.recommendedSeniorityLevel}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 flex-wrap">
                {res.currentRole && (
                  <span className="flex items-center gap-1">
                    <Briefcase className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{res.currentRole}</span>
                  </span>
                )}
                {res.totalExperienceYears !== undefined && (
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{res.totalExperienceYears} Years Experience</span>
                  </span>
                )}
                {res.educationSummary && (
                  <span className="flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5 text-purple-400" />
                    <span className="truncate max-w-xs">{res.educationSummary}</span>
                  </span>
                )}
                {!biasShield && res.candidateLocation && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{res.candidateLocation}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              title="Print Screening Dossier"
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Top Score Matrix Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
            {/* Primary Score Ring Card */}
            <div className="md:col-span-4 bg-slate-950/70 border border-slate-800 rounded-xl p-5 flex flex-col items-center justify-center text-center">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono-code">
                Overall Alignment
              </span>
              <div className="relative w-28 h-28 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-800"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className={
                      res.matchScore >= 85 ? 'text-emerald-500' :
                      res.matchScore >= 70 ? 'text-cyan-500' :
                      res.matchScore >= 50 ? 'text-amber-500' : 'text-rose-500'
                    }
                    strokeDasharray={`${res.matchScore}, 100`}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute flex flex-col items-center">
                  <span className="text-3xl font-extrabold text-white font-mono-code">
                    {res.matchScore}%
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase font-mono-code">Match</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-3 font-mono-code">
                Evaluated with Gemini 3.8 Flash
              </p>
            </div>

            {/* Dimensional Score Breakdown Bars */}
            <div className="md:col-span-8 bg-slate-950/70 border border-slate-800 rounded-xl p-5 space-y-3 flex flex-col justify-center">
              <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono-code">
                Multi-Factor Evaluation Dimensions
              </h4>

              <div className="space-y-2.5">
                {[
                  { label: 'Technical Hard Skills Match', val: res.scoreBreakdown.technicalSkills, color: 'bg-cyan-500' },
                  { label: 'Relevant Experience & Depth', val: res.scoreBreakdown.relevantExperience, color: 'bg-indigo-500' },
                  { label: 'Education & Certifications', val: res.scoreBreakdown.educationCertifications, color: 'bg-purple-500' },
                  { label: 'Industry Domain Fit', val: res.scoreBreakdown.domainAlignment, color: 'bg-emerald-500' },
                  { label: 'Leadership & Soft Skills', val: res.scoreBreakdown.softSkillsLeadership, color: 'bg-amber-500' },
                ].map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-medium">{item.label}</span>
                      <span className="font-mono-code font-bold text-white">{item.val}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div 
                        className={`h-full ${item.color} transition-all duration-500`} 
                        style={{ width: `${item.val}%` }} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 font-mono-code uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Executive Hiring Verdict</span>
            </div>
            <p className="text-xs text-slate-200 leading-relaxed font-sans">
              {res.executiveSummary}
            </p>
          </div>

          {/* Skills Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Matched Skills */}
            <div className="bg-slate-950/50 border border-emerald-900/30 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>Matched Skills ({res.matchedSkills.length})</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {res.matchedSkills.map((sk, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 px-2 py-0.5 rounded font-mono-code"
                  >
                    ✓ {sk}
                  </span>
                ))}
                {res.matchedSkills.length === 0 && (
                  <span className="text-xs text-slate-500">None detected</span>
                )}
              </div>
            </div>

            {/* Missing Crucial Skills */}
            <div className="bg-slate-950/50 border border-rose-900/30 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-400">
                <AlertTriangle className="w-4 h-4" />
                <span>Missing Crucial Skills ({res.missingCrucialSkills.length})</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {res.missingCrucialSkills.map((sk, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] bg-rose-950/60 border border-rose-800/40 text-rose-300 px-2 py-0.5 rounded font-mono-code"
                  >
                    ✕ {sk}
                  </span>
                ))}
                {res.missingCrucialSkills.length === 0 && (
                  <span className="text-xs text-emerald-400">No critical skill gaps identified!</span>
                )}
              </div>
            </div>

            {/* Nice to have */}
            <div className="bg-slate-950/50 border border-purple-900/30 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-400">
                <Award className="w-4 h-4" />
                <span>Bonus Qualifications ({(res.niceToHaveSkillsPresent || []).length})</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(res.niceToHaveSkillsPresent || []).map((sk, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] bg-purple-950/60 border border-purple-800/40 text-purple-300 px-2 py-0.5 rounded font-mono-code"
                  >
                    + {sk}
                  </span>
                ))}
                {(!res.niceToHaveSkillsPresent || res.niceToHaveSkillsPresent.length === 0) && (
                  <span className="text-xs text-slate-500">No bonus skills flagged</span>
                )}
              </div>
            </div>
          </div>

          {/* Strengths & Potential Gaps */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 space-y-2">
              <h4 className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Key Candidate Strengths</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {res.keyStrengths.map((str, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 space-y-2">
              <h4 className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Areas of Concern / Skill Gaps</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {res.potentialGaps.map((gap, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{gap}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Red Flags / Tenure warnings if any */}
          {res.redFlagsOrConcerns && res.redFlagsOrConcerns.length > 0 && (
            <div className="bg-rose-950/30 border border-rose-800/40 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-400">
                <AlertTriangle className="w-4 h-4" />
                <span>Inconsistencies or Tenure Inquiries Flagged</span>
              </div>
              <ul className="space-y-1 text-xs text-rose-200">
                {res.redFlagsOrConcerns.map((rf, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>{rf}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Custom Tailored Interview Questions */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-cyan-400" />
                <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono-code">
                  AI-Tailored Probing Interview Questions
                </h4>
              </div>
              <span className="text-[11px] text-slate-400">Targeted to Candidate Gaps</span>
            </div>

            <div className="space-y-3">
              {res.customizedInterviewQuestions.map((q, idx) => (
                <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
                  <div className="text-xs font-semibold text-cyan-300">
                    Q{idx + 1}: {q.question}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    <strong className="text-slate-300">Why ask this:</strong> {q.reason}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    <strong className="text-slate-300">What to look for:</strong> {q.expectedAnswerTheme}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Constructive Applicant Feedback */}
          {res.applicantFeedbackTips && res.applicantFeedbackTips.length > 0 && (
            <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-400 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Constructive Feedback for Applicant</span>
                </span>
                <button
                  onClick={handleCopyFeedback}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2 py-0.5 rounded bg-slate-800 transition-colors"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy Feedback'}</span>
                </button>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {res.applicantFeedbackTips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-indigo-400 font-bold">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="text-xs text-slate-400 font-mono-code">
            Candidate ID: {candidate.id}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
            >
              Close Dossier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
