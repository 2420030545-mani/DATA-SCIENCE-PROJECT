import React from 'react';
import { 
  Sparkles, 
  FileCheck2, 
  ShieldCheck, 
  SlidersHorizontal, 
  FileText, 
  PlusCircle,
  HelpCircle,
  CheckCircle2
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'studio' | 'leaderboard' | 'jd-architect' | 'bullet-polisher';
  setActiveTab: (tab: 'studio' | 'leaderboard' | 'jd-architect' | 'bullet-polisher') => void;
  candidateCount: number;
  evaluatedCount: number;
  biasShield: boolean;
  setBiasShield: (val: boolean) => void;
  apiKeyActive: boolean;
  onOpenNewUpload: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  candidateCount,
  evaluatedCount,
  biasShield,
  setBiasShield,
  apiKeyActive,
  onOpenNewUpload,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-40 transition-all">
      {/* Top Banner echoing the exact title in the user's reference image */}
      <div className="border-b border-slate-900 bg-black/90 py-3.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-center md:text-left">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <FileCheck2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-cinzel text-lg sm:text-xl md:text-2xl font-black tracking-widest text-white uppercase drop-shadow-sm">
                AI-BASED RESUME SCREENING SYSTEM
              </h1>
              <div className="flex items-center justify-center md:justify-start gap-2 text-xs text-slate-400 mt-0.5">
                <span className="inline-flex items-center gap-1 font-mono-code text-[11px] text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2 py-0.5 rounded">
                  <Sparkles className="w-3 h-3 animate-pulse" /> GEMINI 3.8 FLASH ENGINE
                </span>
                <span className="hidden sm:inline text-slate-600">•</span>
                <span className="hidden sm:inline text-slate-400 text-xs">ATS Semantic Alignment & Deep Candidate Profiling</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Bias Shield Toggle */}
            <button
              onClick={() => setBiasShield(!biasShield)}
              title="When enabled, applicant name, photo, gender indicators, and graduation dates are hidden during screening to ensure objective evaluation"
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                biasShield
                  ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-950'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:border-slate-600'
              }`}
            >
              <ShieldCheck className={`w-3.5 h-3.5 ${biasShield ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span>Bias Shield:</span>
              <span className={`font-mono-code uppercase font-semibold text-[10px] px-1.5 py-0.2 rounded ${biasShield ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>
                {biasShield ? 'ACTIVE' : 'OFF'}
              </span>
            </button>

            {/* Quick System Status Indicator */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>API Ready</span>
            </div>

            <button
              onClick={onOpenNewUpload}
              className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md shadow-indigo-600/25 transition-all"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Upload Resumes</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Sub-bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between overflow-x-auto py-2.5 no-scrollbar gap-4">
          <nav className="flex items-center space-x-1 sm:space-x-2 text-xs font-medium">
            <button
              onClick={() => setActiveTab('studio')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
                activeTab === 'studio'
                  ? 'bg-slate-800 text-white font-semibold shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Screening Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
                activeTab === 'leaderboard'
                  ? 'bg-slate-800 text-white font-semibold shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <FileCheck2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Candidate Matrix</span>
              {evaluatedCount > 0 && (
                <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-indigo-500/20 text-indigo-300 font-mono-code font-bold">
                  {evaluatedCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('jd-architect')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
                activeTab === 'jd-architect'
                  ? 'bg-slate-800 text-white font-semibold shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>JD Architect & Rubric</span>
            </button>

            <button
              onClick={() => setActiveTab('bullet-polisher')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-all ${
                activeTab === 'bullet-polisher'
                  ? 'bg-slate-800 text-white font-semibold shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Resume Bullet Optimizer</span>
            </button>
          </nav>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="hidden md:inline font-mono-code">
              Candidates in Pool: <strong className="text-white">{candidateCount}</strong>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
