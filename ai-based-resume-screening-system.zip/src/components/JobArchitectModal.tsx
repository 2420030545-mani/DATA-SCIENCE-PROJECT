import React, { useState } from 'react';
import { 
  Sparkles, 
  FileText, 
  RotateCw, 
  CheckCircle2, 
  ArrowRight, 
  Copy, 
  Check, 
  SlidersHorizontal,
  Layers
} from 'lucide-react';

interface JobArchitectProps {
  onApplyToStudio: (job: { title: string; description: string; templateId: string }) => void;
}

export const JobArchitectModal: React.FC<JobArchitectProps> = ({ onApplyToStudio }) => {
  const [roleTitle, setRoleTitle] = useState('Staff Platform & Infrastructure Engineer');
  const [seniority, setSeniority] = useState('Staff / Lead (7+ Years)');
  const [industry, setIndustry] = useState('Enterprise Cloud & FinTech');
  const [keySkills, setKeySkills] = useState('Kubernetes, Terraform, AWS/GCP, Golang, CI/CD, Observability, Distributed Systems');
  const [context, setContext] = useState('Fast-growing platform team migrating from legacy VMs to automated container orchestration with 99.99% availability.');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedJD, setGeneratedJD] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [applied, setApplied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleTitle.trim()) return;

    setIsGenerating(true);
    setApplied(false);
    try {
      const response = await fetch('/api/generate-jd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: roleTitle,
          seniority,
          industry,
          keySkills,
          companyContext: context,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate job description.');
      }

      const resData = await response.json();
      setGeneratedJD(resData.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApplyToEngine = () => {
    if (!generatedJD) return;
    onApplyToStudio({
      title: generatedJD.jobTitle || roleTitle,
      description: generatedJD.fullFormattedMarkdown || JSON.stringify(generatedJD, null, 2),
      templateId: 'custom-architected',
    });
    setApplied(true);
    setTimeout(() => setApplied(false), 2500);
  };

  const handleCopyMarkdown = () => {
    if (!generatedJD?.fullFormattedMarkdown) return;
    navigator.clipboard.writeText(generatedJD.fullFormattedMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-cinzel">
            AI Job Description Architect & Rubric Builder
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Generate bias-free, ATS-optimized job descriptions with quantifiable screening rubrics powered by Gemini 3.8.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Form: Parameters */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Role Title:
              </label>
              <input
                type="text"
                value={roleTitle}
                onChange={(e) => setRoleTitle(e.target.value)}
                placeholder="e.g. Senior Machine Learning Engineer"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Seniority Level:
                </label>
                <select
                  value={seniority}
                  onChange={(e) => setSeniority(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="Junior / Entry (1-2 Years)">Junior / Entry (1-2 Years)</option>
                  <option value="Mid-Level (3-5 Years)">Mid-Level (3-5 Years)</option>
                  <option value="Senior (5-7 Years)">Senior (5-7 Years)</option>
                  <option value="Staff / Lead (7+ Years)">Staff / Lead (7+ Years)</option>
                  <option value="Principal / Director (10+ Years)">Principal / Director (10+ Years)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Industry / Domain:
                </label>
                <input
                  type="text"
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  placeholder="e.g. Healthcare Tech, FinTech"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Core Tech Stack & Must-Have Skills:
              </label>
              <textarea
                rows={3}
                value={keySkills}
                onChange={(e) => setKeySkills(e.target.value)}
                placeholder="List technologies, frameworks, methodologies..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 font-mono-code focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Company / Team Mission Context:
              </label>
              <textarea
                rows={3}
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="Key challenges, culture, growth goals..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <button
              type="submit"
              disabled={isGenerating || !roleTitle.trim()}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 disabled:opacity-50 text-white font-semibold py-2.5 rounded-lg text-xs shadow-md transition-all"
            >
              {isGenerating ? (
                <>
                  <RotateCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing JD & Rubric with Gemini...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate Job Description & Screening Rubric</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Preview */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" />
              <h3 className="font-semibold text-white text-sm">Generated Specification</h3>
            </div>

            {generatedJD && (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyMarkdown}
                  className="flex items-center gap-1 text-xs text-slate-300 hover:text-white px-2.5 py-1 rounded bg-slate-800 border border-slate-700 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy JD'}</span>
                </button>
                <button
                  onClick={handleApplyToEngine}
                  className="flex items-center gap-1.5 text-xs text-white px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 font-semibold shadow transition-all"
                >
                  {applied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                  <span>{applied ? 'Applied to Engine!' : 'Use in Screening Studio'}</span>
                </button>
              </div>
            )}
          </div>

          {!generatedJD && !isGenerating && (
            <div className="p-12 text-center text-slate-500 text-xs">
              Configure parameters on the left and click Generate to produce an enterprise-grade JD and ATS screening rubric.
            </div>
          )}

          {isGenerating && (
            <div className="p-16 text-center space-y-3">
              <RotateCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto" />
              <p className="text-xs text-slate-300 font-mono-code">
                Constructing role requirements, responsibilities, and recruiter screening weights...
              </p>
            </div>
          )}

          {generatedJD && (
            <div className="space-y-4 text-xs">
              <div>
                <h4 className="text-base font-bold text-white font-cinzel">{generatedJD.jobTitle}</h4>
                <p className="text-slate-400 text-xs mt-0.5">
                  Seniority: <strong className="text-slate-200">{generatedJD.seniorityLevel}</strong> • Min Experience:{' '}
                  <strong className="text-slate-200">{generatedJD.minimumExperienceYears} years</strong>
                </p>
              </div>

              {/* Summary */}
              <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800 text-slate-300 leading-relaxed">
                {generatedJD.summary}
              </div>

              {/* Screening Rubric */}
              {generatedJD.screeningRubric && (
                <div className="space-y-2">
                  <span className="text-[11px] font-mono-code text-cyan-400 font-semibold uppercase">
                    Recruiter Screening Weight Rubric
                  </span>
                  <div className="space-y-1.5">
                    {generatedJD.screeningRubric.map((rub: any, idx: number) => (
                      <div key={idx} className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 flex items-start justify-between gap-3">
                        <div>
                          <div className="font-semibold text-white">{rub.criteria}</div>
                          <div className="text-[11px] text-slate-400">{rub.guidanceForRecruiter}</div>
                        </div>
                        <span className="font-mono-code font-bold text-cyan-400 shrink-0 text-xs">
                          {rub.weightPercentage}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Responsibilities */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-mono-code text-slate-400 uppercase font-semibold">
                  Core Responsibilities
                </span>
                <ul className="space-y-1 text-slate-300">
                  {generatedJD.keyResponsibilities?.map((resp: string, idx: number) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-cyan-400">•</span>
                      <span>{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Skills */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                  <span className="text-[11px] font-mono-code text-emerald-400 uppercase font-semibold block mb-1">
                    Must-Have Skills
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {generatedJD.mustHaveSkills?.map((s: string, idx: number) => (
                      <span key={idx} className="text-[10px] bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 px-1.5 py-0.5 rounded font-mono-code">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                  <span className="text-[11px] font-mono-code text-purple-400 uppercase font-semibold block mb-1">
                    Nice-to-Have Skills
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {generatedJD.niceToHaveSkills?.map((s: string, idx: number) => (
                      <span key={idx} className="text-[10px] bg-purple-950/60 border border-purple-800/40 text-purple-300 px-1.5 py-0.5 rounded font-mono-code">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
