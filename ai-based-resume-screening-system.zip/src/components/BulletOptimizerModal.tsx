import React, { useState } from 'react';
import { Sparkles, RotateCw, Copy, Check, ArrowRight, Lightbulb, CheckCircle2 } from 'lucide-react';

export const BulletOptimizerModal: React.FC = () => {
  const [originalBullet, setOriginalBullet] = useState(
    'Worked on the backend API and made the database faster for users.'
  );
  const [targetRole, setTargetRole] = useState('Senior Backend / Full Stack Engineer');
  const [keyTech, setKeyTech] = useState('Node.js, PostgreSQL, Redis, AWS');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [results, setResults] = useState<{
    improvedVariations: string[];
    explanationOfChanges: string;
  } | null>(null);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleOptimize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!originalBullet.trim()) return;

    setIsOptimizing(true);
    try {
      const response = await fetch('/api/optimize-bullet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originalBullet,
          targetRole,
          keyTechnology: keyTech,
        }),
      });

      if (!response.ok) throw new Error('Failed to optimize bullet.');
      const data = await response.json();
      setResults(data.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white font-cinzel">
          ATS Resume Bullet Point Optimizer
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Transform generic duties into high-impact accomplishments following the Google XYZ formula:
          "Accomplished [X] as measured by [Y], by doing [Z]".
        </p>
      </div>

      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-5">
        <form onSubmit={handleOptimize} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Original Resume Bullet Point:
            </label>
            <textarea
              rows={3}
              value={originalBullet}
              onChange={(e) => setOriginalBullet(e.target.value)}
              placeholder="e.g. Responsible for building the login page and authentication system."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-100 font-mono-code focus:outline-none focus:border-cyan-500"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Role:
              </label>
              <input
                type="text"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                placeholder="e.g. Senior Frontend Engineer"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Tech / Tooling:
              </label>
              <input
                type="text"
                value={keyTech}
                onChange={(e) => setKeyTech(e.target.value)}
                placeholder="e.g. React, Next.js, Redux Toolkit"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isOptimizing || !originalBullet.trim()}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 via-indigo-600 to-cyan-600 hover:from-amber-500 hover:to-cyan-500 disabled:opacity-50 text-white font-semibold px-5 py-2.5 rounded-lg text-xs shadow-md transition-all"
          >
            {isOptimizing ? (
              <>
                <RotateCw className="w-3.5 h-3.5 animate-spin" />
                <span>Rewriting for High ATS Match...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Elevate with Action Verbs & Metrics</span>
              </>
            )}
          </button>
        </form>

        {results && (
          <div className="pt-4 border-t border-slate-800 space-y-4 animate-in fade-in duration-300">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 font-mono-code uppercase">
              <Lightbulb className="w-4 h-4" />
              <span>Recommended High-Impact Variations</span>
            </div>

            <div className="space-y-3">
              {results.improvedVariations.map((variation, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-start justify-between gap-4 transition-all"
                >
                  <div className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-indigo-950/80 border border-indigo-700/60 text-indigo-300 flex items-center justify-center text-[10px] font-bold font-mono-code shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="text-xs text-slate-200 leading-relaxed font-sans">
                      {variation}
                    </p>
                  </div>
                  <button
                    onClick={() => handleCopy(variation, idx)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white shrink-0 transition-colors"
                    title="Copy bullet point"
                  >
                    {copiedIdx === idx ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              ))}
            </div>

            {results.explanationOfChanges && (
              <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3.5 text-xs text-slate-400">
                <strong className="text-slate-300 font-medium">Why these work better: </strong>
                {results.explanationOfChanges}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
