import React, { useState } from 'react';
import { 
  Upload, 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  Sliders, 
  Trash2, 
  RotateCw, 
  ShieldCheck, 
  ArrowRight,
  TrendingUp,
  Award,
  Users,
  Search,
  BookOpen
} from 'lucide-react';
import { CandidateItem, JobTemplate, ScreeningResult } from '../types';
import { DEFAULT_JOB_TEMPLATES, SAMPLE_CANDIDATES } from '../data/mockTemplates';

interface ScreeningStudioProps {
  candidates: CandidateItem[];
  setCandidates: React.Dispatch<React.SetStateAction<CandidateItem[]>>;
  activeJob: {
    title: string;
    description: string;
    templateId: string;
  };
  setActiveJob: React.Dispatch<React.SetStateAction<{
    title: string;
    description: string;
    templateId: string;
  }>>;
  biasShield: boolean;
  setBiasShield: (val: boolean) => void;
  onSelectCandidate: (candidate: CandidateItem) => void;
  onNavigateToLeaderboard: () => void;
}

export const ScreeningStudio: React.FC<ScreeningStudioProps> = ({
  candidates,
  setCandidates,
  activeJob,
  setActiveJob,
  biasShield,
  setBiasShield,
  onSelectCandidate,
  onNavigateToLeaderboard,
}) => {
  const [strictnessLevel, setStrictnessLevel] = useState<'lenient' | 'balanced' | 'strict'>('balanced');
  const [isScreeningBatch, setIsScreeningBatch] = useState(false);
  const [screeningProgress, setScreeningProgress] = useState({ current: 0, total: 0 });
  const [pasteResumeText, setPasteResumeText] = useState('');
  const [pasteCandidateName, setPasteCandidateName] = useState('');
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Quick stats calculation
  const completedCandidates = candidates.filter(c => c.status === 'completed' && c.result);
  const avgScore = completedCandidates.length > 0 
    ? Math.round(completedCandidates.reduce((acc, c) => acc + (c.result?.matchScore || 0), 0) / completedCandidates.length) 
    : 0;
  const shortlistedCount = completedCandidates.filter(c => 
    c.result?.recommendation === 'Strong Hire' || c.result?.recommendation === 'Hire'
  ).length;

  const handleSelectTemplate = (templateId: string) => {
    const found = DEFAULT_JOB_TEMPLATES.find(t => t.id === templateId);
    if (found) {
      setActiveJob({
        title: found.title,
        description: found.description,
        templateId: found.id,
      });
    }
  };

  const handleLoadSamplePool = () => {
    setCandidates(SAMPLE_CANDIDATES);
  };

  const handleClearPool = () => {
    setCandidates([]);
  };

  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();

      // If it's a PDF or binary document, read as base64
      if (file.type.includes('pdf') || file.name.endsWith('.pdf')) {
        reader.onload = (e) => {
          const base64Data = e.target?.result as string;
          const newCandidate: CandidateItem = {
            id: `cand-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name.replace(/\.[^/.]+$/, ''),
            fileName: file.name,
            fileBase64: base64Data,
            mimeType: 'application/pdf',
            resumeText: '',
            status: 'idle',
            uploadedAt: 'Just now',
          };
          setCandidates(prev => [newCandidate, ...prev]);
        };
        reader.readAsDataURL(file);
      } else {
        // Plain text, markdown, or code
        reader.onload = (e) => {
          const text = e.target?.result as string;
          const newCandidate: CandidateItem = {
            id: `cand-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name.replace(/\.[^/.]+$/, ''),
            fileName: file.name,
            resumeText: text,
            status: 'idle',
            uploadedAt: 'Just now',
          };
          setCandidates(prev => [newCandidate, ...prev]);
        };
        reader.readAsText(file);
      }
    });
  };

  const handleAddPastedResume = () => {
    if (!pasteResumeText.trim()) return;
    const newCandidate: CandidateItem = {
      id: `cand-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      name: pasteCandidateName.trim() || 'Custom Applicant',
      resumeText: pasteResumeText.trim(),
      status: 'idle',
      uploadedAt: 'Just now',
    };
    setCandidates(prev => [newCandidate, ...prev]);
    setPasteResumeText('');
    setPasteCandidateName('');
    setShowPasteModal(false);
  };

  const screenSingleCandidate = async (candidate: CandidateItem): Promise<CandidateItem> => {
    try {
      const response = await fetch('/api/screen-single', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobTitle: activeJob.title,
          jobDescription: activeJob.description,
          resumeText: candidate.resumeText,
          fileBase64: candidate.fileBase64,
          mimeType: candidate.mimeType,
          fileName: candidate.fileName,
          biasShield,
          strictnessLevel,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status ${response.status}`);
      }

      const resultData = await response.json();
      return {
        ...candidate,
        status: 'completed',
        result: resultData.data,
      };
    } catch (err: any) {
      return {
        ...candidate,
        status: 'error',
        error: err.message || 'Failed to analyze resume.',
      };
    }
  };

  const handleScreenAll = async () => {
    const unanalyzed = candidates.filter(c => c.status === 'idle' || c.status === 'error');
    if (unanalyzed.length === 0) return;

    setIsScreeningBatch(true);
    setScreeningProgress({ current: 0, total: unanalyzed.length });

    // Mark unanalyzed as analyzing
    setCandidates(prev =>
      prev.map(c => unanalyzed.find(u => u.id === c.id) ? { ...c, status: 'analyzing' } : c)
    );

    let count = 0;
    for (const cand of unanalyzed) {
      count++;
      setScreeningProgress({ current: count, total: unanalyzed.length });
      
      const updated = await screenSingleCandidate(cand);
      setCandidates(prev => prev.map(c => (c.id === cand.id ? updated : c)));
    }

    setIsScreeningBatch(false);
  };

  const handleScreenSingleClick = async (cand: CandidateItem) => {
    setCandidates(prev => prev.map(c => c.id === cand.id ? { ...c, status: 'analyzing' } : c));
    const updated = await screenSingleCandidate(cand);
    setCandidates(prev => prev.map(c => c.id === cand.id ? updated : c));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Metrics Header Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Applicants</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-code text-white">{candidates.length}</span>
            <span className="text-xs text-slate-500">in pool</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            {completedCandidates.length} evaluated by AI
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Average Match</span>
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-code text-white">
              {avgScore > 0 ? `${avgScore}%` : '—'}
            </span>
            <span className="text-xs text-indigo-400">ATS Alignment</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Weighted on skill & experience
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Shortlisted Rate</span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-code text-emerald-400">
              {completedCandidates.length > 0 
                ? `${Math.round((shortlistedCount / completedCandidates.length) * 100)}%` 
                : '—'}
            </span>
            <span className="text-xs text-slate-400">({shortlistedCount} candidates)</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Strong Hire & Hire verdicts
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Screening Protocol</span>
            <ShieldCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-semibold text-white uppercase font-mono-code">
              {strictnessLevel}
            </span>
            <span className="text-xs text-purple-400">
              {biasShield ? '• Shield On' : '• Standard'}
            </span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400">
            Multi-factor scoring rubric
          </div>
        </div>
      </div>

      {/* Main Workspace Split: Left (Job Description & Config), Right (Candidate Uploader & Processing) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Job Description Target */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <h2 className="font-semibold text-white text-sm">Target Job Description</h2>
              </div>
              <span className="text-[11px] text-slate-400 font-mono-code">Benchmark Profile</span>
            </div>

            {/* Template Selector dropdown */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Load Standard Role Template:
              </label>
              <select
                value={activeJob.templateId}
                onChange={(e) => handleSelectTemplate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {DEFAULT_JOB_TEMPLATES.map((tmpl) => (
                  <option key={tmpl.id} value={tmpl.id}>
                    {tmpl.title} ({tmpl.seniority})
                  </option>
                ))}
              </select>
            </div>

            {/* Role Title Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Role Title:
              </label>
              <input
                type="text"
                value={activeJob.title}
                onChange={(e) => setActiveJob(prev => ({ ...prev, title: e.target.value }))}
                placeholder="e.g. Senior Full Stack Engineer"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Job Description Textarea */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-300">
                  Full Job Description & Requirements:
                </label>
                <span className="text-[10px] text-slate-500 font-mono-code">
                  {activeJob.description.length} chars
                </span>
              </div>
              <textarea
                rows={12}
                value={activeJob.description}
                onChange={(e) => setActiveJob(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Paste the target job description, required skills, responsibilities, and experience criteria here..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-300 font-mono-code leading-relaxed focus:outline-none focus:border-cyan-500 resize-y"
              />
            </div>

            {/* Strictness & Bias Controls */}
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Screening Strictness Level:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['lenient', 'balanced', 'strict'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setStrictnessLevel(lvl)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-medium capitalize border transition-all ${
                        strictnessLevel === lvl
                          ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300 shadow-sm'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Candidate Uploads & Screening Engine */}
        <div className="lg:col-span-7 space-y-4">
          {/* Uploader Box */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-white text-sm">Applicant Pipeline & Screening</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Drop candidate resumes (PDF, TXT, DOCX) or paste text to evaluate against the JD.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleLoadSamplePool}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 border border-indigo-700/50 hover:bg-indigo-900/50 text-indigo-300 text-xs font-medium transition-all"
                  title="Populates 4 diverse candidate resumes with pre-analyzed and raw benchmarks"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Load 4 Sample Resumes</span>
                </button>
                {candidates.length > 0 && (
                  <button
                    onClick={handleClearPool}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Clear current candidate pool"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Drop Zone */}
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActive(false);
                handleFileUpload(e.dataTransfer.files);
              }}
              className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
                dragActive
                  ? 'border-cyan-400 bg-cyan-950/20'
                  : 'border-slate-700/80 hover:border-slate-600 bg-slate-950/60'
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-cyan-400 mb-3 shadow-inner">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-medium text-slate-200">
                Drag and drop resumes here, or{' '}
                <label className="text-cyan-400 underline cursor-pointer hover:text-cyan-300">
                  browse files
                  <input
                    type="file"
                    multiple
                    accept=".pdf,.txt,.doc,.docx,image/*"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                  />
                </label>
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Supports PDF, DOCX, TXT, or Image Resumes (multimodal processing via Gemini 3.8 Flash)
              </p>

              <div className="mt-3 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowPasteModal(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-xs text-slate-300 bg-slate-800/80 hover:bg-slate-700 rounded-md border border-slate-700 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-slate-400" />
                  <span>Paste Resume Text</span>
                </button>
              </div>
            </div>

            {/* Batch Action Toolbar */}
            {candidates.length > 0 && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800">
                <div className="text-xs text-slate-400">
                  <span>{candidates.length} candidate(s) loaded</span>
                  {candidates.some(c => c.status === 'idle') && (
                    <span className="text-amber-400 ml-2">
                      ({candidates.filter(c => c.status === 'idle').length} pending screening)
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5 w-full sm:w-auto">
                  <button
                    disabled={isScreeningBatch || !candidates.some(c => c.status === 'idle' || c.status === 'error')}
                    onClick={handleScreenAll}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 disabled:opacity-50 text-white font-semibold px-4 py-2 rounded-lg text-xs shadow-md shadow-indigo-600/20 transition-all"
                  >
                    {isScreeningBatch ? (
                      <>
                        <RotateCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Screening ({screeningProgress.current}/{screeningProgress.total})...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Run AI Screening On Pool</span>
                      </>
                    )}
                  </button>

                  {completedCandidates.length > 0 && (
                    <button
                      onClick={onNavigateToLeaderboard}
                      className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-700 transition-colors"
                    >
                      <span>View Matrix</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Candidate Pool List */}
          <div className="space-y-3">
            {candidates.length === 0 ? (
              <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-8 text-center">
                <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <h3 className="text-sm font-semibold text-slate-300">No Resumes in Pool</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
                  Upload candidate CVs or click below to load pre-configured sample applicants to test the screening engine immediately.
                </p>
                <button
                  onClick={handleLoadSamplePool}
                  className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-md transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Load Sample Candidates</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {candidates.map((cand) => {
                  const res = cand.result;
                  const isCompleted = cand.status === 'completed' && res;
                  const isAnalyzing = cand.status === 'analyzing';

                  // Score badge coloring
                  let scoreBadgeClass = 'bg-slate-800 text-slate-400 border-slate-700';
                  if (res) {
                    if (res.matchScore >= 85) scoreBadgeClass = 'bg-emerald-950/80 text-emerald-300 border-emerald-600/60';
                    else if (res.matchScore >= 70) scoreBadgeClass = 'bg-cyan-950/80 text-cyan-300 border-cyan-600/60';
                    else if (res.matchScore >= 50) scoreBadgeClass = 'bg-amber-950/80 text-amber-300 border-amber-600/60';
                    else scoreBadgeClass = 'bg-rose-950/80 text-rose-300 border-rose-600/60';
                  }

                  return (
                    <div
                      key={cand.id}
                      className="bg-slate-900/90 border border-slate-800/80 hover:border-slate-700 rounded-xl p-4 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700/80 flex items-center justify-center text-slate-300 shrink-0 font-bold text-xs uppercase font-mono-code">
                          {cand.name.substring(0, 2)}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="font-semibold text-white text-sm truncate">
                              {biasShield && res?.candidateName ? res.candidateName : cand.name}
                            </h4>
                            {isCompleted && (
                              <span className={`text-[10px] font-bold uppercase font-mono-code px-2 py-0.5 rounded border ${
                                res.recommendation === 'Strong Hire' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                                res.recommendation === 'Hire' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' :
                                res.recommendation === 'Consider' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                                'bg-rose-500/20 text-rose-300 border-rose-500/40'
                              }`}>
                                {res.recommendation}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                            {res?.currentRole ? (
                              <span className="truncate">{res.currentRole}</span>
                            ) : (
                              <span>{cand.fileName || 'Pasted Resume'}</span>
                            )}
                            <span>•</span>
                            <span className="text-[11px] text-slate-500">{cand.uploadedAt}</span>
                          </div>

                          {isCompleted && (
                            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                              {res.matchedSkills.slice(0, 4).map((sk, idx) => (
                                <span key={idx} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700/60 font-mono-code">
                                  {sk}
                                </span>
                              ))}
                              {res.matchedSkills.length > 4 && (
                                <span className="text-[10px] text-slate-500">
                                  +{res.matchedSkills.length - 4} more
                                </span>
                              )}
                            </div>
                          )}

                          {cand.status === 'error' && (
                            <div className="flex items-center gap-1.5 text-xs text-rose-400 mt-1">
                              <AlertCircle className="w-3.5 h-3.5" />
                              <span>{cand.error || 'Evaluation failed'}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right Side: Score & Actions */}
                      <div className="flex items-center gap-3 shrink-0 self-end sm:self-center w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800/80">
                        {isCompleted && (
                          <div className="flex items-center gap-3">
                            <div className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-mono-code font-bold text-xs ${scoreBadgeClass}`}>
                              <span>Score:</span>
                              <span className="text-sm">{res.matchScore}%</span>
                            </div>
                            <button
                              onClick={() => onSelectCandidate(cand)}
                              className="px-3 py-1.5 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
                            >
                              <span>View Dossier</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        {isAnalyzing && (
                          <div className="flex items-center gap-2 text-xs text-cyan-400">
                            <RotateCw className="w-3.5 h-3.5 animate-spin" />
                            <span className="font-mono-code">Analyzing with Gemini...</span>
                          </div>
                        )}

                        {cand.status === 'idle' && (
                          <button
                            onClick={() => handleScreenSingleClick(cand)}
                            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                            <span>Screen Now</span>
                          </button>
                        )}

                        {cand.status === 'error' && (
                          <button
                            onClick={() => handleScreenSingleClick(cand)}
                            className="px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-700 text-rose-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
                          >
                            <RotateCw className="w-3.5 h-3.5" />
                            <span>Retry</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Paste Resume Modal */}
      {showPasteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <h3 className="font-semibold text-white text-base">Paste Candidate Resume</h3>
              </div>
              <button
                onClick={() => setShowPasteModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono-code"
              >
                ✕ Close
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Candidate Name / Identifier (Optional):
              </label>
              <input
                type="text"
                value={pasteCandidateName}
                onChange={(e) => setPasteCandidateName(e.target.value)}
                placeholder="e.g. Jordan Taylor"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Resume Content (Text):
              </label>
              <textarea
                rows={9}
                value={pasteResumeText}
                onChange={(e) => setPasteResumeText(e.target.value)}
                placeholder="Paste work experience, technical skills, education, certifications, and portfolio details..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-200 font-mono-code focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowPasteModal(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!pasteResumeText.trim()}
                onClick={handleAddPastedResume}
                className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white shadow-md transition-all"
              >
                Add To Candidate Pool
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
