import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  Download, 
  Eye, 
  CheckSquare, 
  Square, 
  Sparkles, 
  FileSpreadsheet, 
  FileCheck2,
  ChevronRight,
  Shield,
  Layers,
  ArrowRight
} from 'lucide-react';
import { CandidateItem } from '../types';

interface CandidateLeaderboardProps {
  candidates: CandidateItem[];
  biasShield: boolean;
  onSelectCandidate: (candidate: CandidateItem) => void;
  selectedForCompare: string[];
  setSelectedForCompare: React.Dispatch<React.SetStateAction<string[]>>;
  onOpenCompare: () => void;
}

export const CandidateLeaderboard: React.FC<CandidateLeaderboardProps> = ({
  candidates,
  biasShield,
  onSelectCandidate,
  selectedForCompare,
  setSelectedForCompare,
  onOpenCompare,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRecommendation, setFilterRecommendation] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'score' | 'tech' | 'exp' | 'name'>('score');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Filter evaluated candidates
  const evaluatedCandidates = candidates.filter(c => c.status === 'completed' && c.result);

  const filteredCandidates = evaluatedCandidates
    .filter(cand => {
      const res = cand.result!;
      const name = biasShield ? (res.candidateName || 'Candidate') : cand.name;
      const role = res.currentRole || '';
      const skills = (res.matchedSkills || []).join(' ');
      const query = searchQuery.toLowerCase();

      const matchesSearch = 
        name.toLowerCase().includes(query) || 
        role.toLowerCase().includes(query) || 
        skills.toLowerCase().includes(query);

      const matchesFilter = 
        filterRecommendation === 'all' || 
        res.recommendation.toLowerCase().replace(' ', '-') === filterRecommendation.toLowerCase();

      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      const resA = a.result!;
      const resB = b.result!;
      let diff = 0;

      if (sortBy === 'score') diff = resA.matchScore - resB.matchScore;
      else if (sortBy === 'tech') diff = resA.scoreBreakdown.technicalSkills - resB.scoreBreakdown.technicalSkills;
      else if (sortBy === 'exp') diff = (resA.totalExperienceYears || 0) - (resB.totalExperienceYears || 0);
      else if (sortBy === 'name') diff = a.name.localeCompare(b.name);

      return sortOrder === 'desc' ? -diff : diff;
    });

  const toggleCompare = (id: string) => {
    if (selectedForCompare.includes(id)) {
      setSelectedForCompare(prev => prev.filter(item => item !== id));
    } else {
      if (selectedForCompare.length >= 3) {
        // max 3 candidates to compare
        setSelectedForCompare([selectedForCompare[1], selectedForCompare[2], id]);
      } else {
        setSelectedForCompare(prev => [...prev, id]);
      }
    }
  };

  const handleExportCSV = () => {
    if (evaluatedCandidates.length === 0) return;

    const headers = [
      'Rank',
      'Candidate Name',
      'Current Role',
      'Experience (Years)',
      'Match Score (%)',
      'Technical Skills Score',
      'Relevant Experience Score',
      'Domain Alignment Score',
      'Education Score',
      'Soft Skills Score',
      'Recommendation',
      'Matched Skills',
      'Missing Crucial Skills',
      'Executive Summary',
    ];

    const rows = evaluatedCandidates.map((c, idx) => {
      const r = c.result!;
      return [
        idx + 1,
        `"${biasShield ? r.candidateName : c.name}"`,
        `"${r.currentRole || ''}"`,
        r.totalExperienceYears || 0,
        r.matchScore,
        r.scoreBreakdown.technicalSkills,
        r.scoreBreakdown.relevantExperience,
        r.scoreBreakdown.domainAlignment,
        r.scoreBreakdown.educationCertifications,
        r.scoreBreakdown.softSkillsLeadership,
        `"${r.recommendation}"`,
        `"${r.matchedSkills.join(', ')}"`,
        `"${r.missingCrucialSkills.join(', ')}"`,
        `"${(r.executiveSummary || '').replace(/"/g, '""')}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `resume_screening_matrix_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    if (evaluatedCandidates.length === 0) return;
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(evaluatedCandidates.map(c => c.result), null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', dataStr);
    link.setAttribute('download', `resume_screening_matrix_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Title & Actions Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white font-cinzel">Candidate Evaluation Matrix</h2>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono-code px-2 py-0.5 rounded-full border border-slate-700">
              {evaluatedCandidates.length} Screened
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Standardized applicant rankings, multi-dimensional alignment scores, and direct candidate comparison.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            disabled={evaluatedCandidates.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-medium disabled:opacity-50 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJSON}
            disabled={evaluatedCandidates.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-medium disabled:opacity-50 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-sm">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search candidates by name, job role, or specific technology skills..."
            className="w-full bg-slate-950 border border-slate-700/80 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 placeholder:text-slate-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {/* Recommendation filter */}
          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs">
            <span className="text-[11px] text-slate-500 px-2 font-medium">Status:</span>
            {['all', 'strong-hire', 'hire', 'consider', 'low-match'].map((status) => (
              <button
                key={status}
                onClick={() => setFilterRecommendation(status)}
                className={`px-2.5 py-1 rounded text-xs capitalize transition-all ${
                  filterRecommendation === status
                    ? 'bg-slate-800 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status.replace('-', ' ')}
              </button>
            ))}
          </div>

          {/* Sort By selector */}
          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs">
            <span className="text-[11px] text-slate-500 font-medium">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-slate-300 text-xs focus:outline-none cursor-pointer"
            >
              <option value="score">Match Score</option>
              <option value="tech">Tech Score</option>
              <option value="exp">Experience</option>
              <option value="name">Name</option>
            </select>
            <button
              onClick={() => setSortOrder(prev => prev === 'desc' ? 'asc' : 'desc')}
              className="p-1 text-slate-400 hover:text-white"
              title={`Sort ${sortOrder === 'desc' ? 'Ascending' : 'Descending'}`}
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Comparison Floating Bar (if candidates selected) */}
      {selectedForCompare.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border border-indigo-700/60 rounded-xl p-3.5 flex items-center justify-between shadow-lg shadow-indigo-950/40 animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white">
                {selectedForCompare.length} Candidate(s) Selected for Side-by-Side Comparison
              </h4>
              <p className="text-[11px] text-indigo-300">
                Compare skill matrix, scoring rubrics, and trade-offs simultaneously (up to 3).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedForCompare([])}
              className="text-xs text-slate-400 hover:text-white px-2 py-1"
            >
              Clear
            </button>
            <button
              onClick={onOpenCompare}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shadow-md transition-colors"
            >
              <span>Launch Comparison Matrix</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Leaderboard Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        {filteredCandidates.length === 0 ? (
          <div className="p-12 text-center">
            <FileCheck2 className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-slate-300">No Evaluated Candidates Found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Run AI screening in the Screening Studio first, or adjust your filter query above.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/70 text-[11px] font-mono-code text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4 w-12 text-center">Compare</th>
                  <th className="py-3 px-4 w-12">#</th>
                  <th className="py-3 px-4">Candidate & Background</th>
                  <th className="py-3 px-4 text-center">Overall Fit</th>
                  <th className="py-3 px-4">Score Breakdown</th>
                  <th className="py-3 px-4">Matched Skills</th>
                  <th className="py-3 px-4">Recommendation</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {filteredCandidates.map((cand, idx) => {
                  const res = cand.result!;
                  const isChecked = selectedForCompare.includes(cand.id);

                  let scoreColor = 'text-emerald-400 bg-emerald-950/60 border-emerald-500/40';
                  if (res.matchScore < 50) scoreColor = 'text-rose-400 bg-rose-950/60 border-rose-500/40';
                  else if (res.matchScore < 70) scoreColor = 'text-amber-400 bg-amber-950/60 border-amber-500/40';
                  else if (res.matchScore < 85) scoreColor = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/40';

                  let recPill = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
                  if (res.recommendation === 'Consider') recPill = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
                  else if (res.recommendation === 'Low Match' || res.recommendation === 'Reject') recPill = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
                  else if (res.recommendation === 'Hire') recPill = 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';

                  return (
                    <tr 
                      key={cand.id}
                      className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                      onClick={() => onSelectCandidate(cand)}
                    >
                      {/* Compare Checkbox */}
                      <td 
                        className="py-3.5 px-4 text-center"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleCompare(cand.id);
                        }}
                      >
                        <button className="text-slate-400 hover:text-white">
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-indigo-400" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-600 group-hover:text-slate-400" />
                          )}
                        </button>
                      </td>

                      {/* Rank */}
                      <td className="py-3.5 px-4 font-mono-code font-bold text-slate-400">
                        {idx === 0 ? (
                          <span className="w-6 h-6 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center text-xs">
                            1
                          </span>
                        ) : (
                          `#${idx + 1}`
                        )}
                      </td>

                      {/* Candidate info */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-bold font-mono-code text-slate-300 text-xs">
                            {(res.candidateName || cand.name).substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors">
                              {biasShield ? res.candidateName : cand.name}
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <span>{res.currentRole || 'Applicant'}</span>
                              {res.totalExperienceYears !== undefined && (
                                <>
                                  <span>•</span>
                                  <span>{res.totalExperienceYears} yrs exp</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Overall Fit Score */}
                      <td className="py-3.5 px-4 text-center">
                        <div className={`inline-flex items-center justify-center px-3 py-1 rounded-lg border font-mono-code font-bold text-sm ${scoreColor}`}>
                          {res.matchScore}%
                        </div>
                      </td>

                      {/* Score breakdown mini-bars */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1 w-44">
                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono-code">
                            <span>Tech: {res.scoreBreakdown.technicalSkills}%</span>
                            <span>Exp: {res.scoreBreakdown.relevantExperience}%</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden flex">
                            <div 
                              className="bg-cyan-500 h-full" 
                              style={{ width: `${res.scoreBreakdown.technicalSkills}%` }} 
                            />
                          </div>
                        </div>
                      </td>

                      {/* Matched skills chips */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1 flex-wrap max-w-xs">
                          {res.matchedSkills.slice(0, 3).map((sk, sIdx) => (
                            <span 
                              key={sIdx}
                              className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded border border-slate-700/60 font-mono-code"
                            >
                              {sk}
                            </span>
                          ))}
                          {res.matchedSkills.length > 3 && (
                            <span className="text-[10px] text-slate-500 font-mono-code">
                              +{res.matchedSkills.length - 3}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Recommendation */}
                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-1 rounded-md text-[11px] font-bold uppercase font-mono-code border ${recPill}`}>
                          {res.recommendation}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectCandidate(cand);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium inline-flex items-center gap-1 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Dossier</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
