import React from 'react';
import { X, CheckCircle2, AlertTriangle, Award, Scale, Sparkles } from 'lucide-react';
import { CandidateItem } from '../types';

interface CompareModalProps {
  candidates: CandidateItem[];
  selectedIds: string[];
  onClose: () => void;
  biasShield: boolean;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  candidates,
  selectedIds,
  onClose,
  biasShield,
}) => {
  const selectedCandidates = candidates.filter(c => selectedIds.includes(c.id) && c.result);

  if (selectedCandidates.length < 2) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-sm text-center">
          <Scale className="w-10 h-10 text-cyan-400 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-white">Select at Least 2 Candidates</h3>
          <p className="text-xs text-slate-400 mt-1 mb-4">
            Please check the compare boxes for 2 or 3 evaluated candidates in the matrix.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold"
          >
            Got it
          </button>
        </div>
      </div>
    );
  }

  // Determine top scorer among selected
  const topCandidate = [...selectedCandidates].sort(
    (a, b) => (b.result?.matchScore || 0) - (a.result?.matchScore || 0)
  )[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-6xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-cinzel">
                Side-by-Side Candidate Calibration Matrix
              </h3>
              <p className="text-xs text-slate-400">
                Direct comparative analysis across technical match, experience depth, and trade-offs.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Table / Columns */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Winner Callout */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-slate-900 border border-emerald-500/30 rounded-xl p-4 flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="text-xs">
              <span className="font-semibold text-emerald-300">Leading Match: </span>
              <strong className="text-white font-mono-code">
                {biasShield ? topCandidate.result?.candidateName : topCandidate.name}
              </strong>
              <span className="text-slate-300"> leads with </span>
              <strong className="text-emerald-400 font-mono-code">{topCandidate.result?.matchScore}%</strong>
              <span className="text-slate-300"> alignment score.</span>
            </div>
          </div>

          {/* Grid of Candidates */}
          <div className={`grid grid-cols-1 md:grid-cols-${selectedCandidates.length} gap-4`}>
            {selectedCandidates.map((cand) => {
              const res = cand.result!;
              const isLead = cand.id === topCandidate.id;
              const name = biasShield ? res.candidateName : cand.name;

              return (
                <div
                  key={cand.id}
                  className={`bg-slate-950/70 border rounded-2xl p-5 space-y-5 flex flex-col justify-between ${
                    isLead ? 'border-cyan-500/60 shadow-lg shadow-cyan-950/30' : 'border-slate-800'
                  }`}
                >
                  {/* Card Header */}
                  <div className="space-y-2">
                    {isLead && (
                      <span className="inline-block text-[10px] font-mono-code font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                        ★ Highest Match Score
                      </span>
                    )}
                    <h4 className="text-base font-bold text-white font-cinzel">{name}</h4>
                    <p className="text-xs text-slate-400">{res.currentRole || 'Applicant'}</p>
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-2xl font-extrabold font-mono-code text-white">
                        {res.matchScore}%
                      </span>
                      <span className={`text-[10px] font-bold uppercase font-mono-code px-2 py-0.5 rounded border ${
                        res.recommendation === 'Strong Hire' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                        res.recommendation === 'Hire' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' :
                        'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      }`}>
                        {res.recommendation}
                      </span>
                    </div>
                  </div>

                  {/* Multi-factor Breakdown */}
                  <div className="space-y-2 pt-3 border-t border-slate-800 text-xs">
                    <span className="text-[11px] font-mono-code text-slate-400 uppercase">
                      Dimensional Scores
                    </span>
                    <div className="space-y-1.5 font-mono-code">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Technical Skills:</span>
                        <span className="text-white font-semibold">{res.scoreBreakdown.technicalSkills}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Experience Depth:</span>
                        <span className="text-white font-semibold">{res.scoreBreakdown.relevantExperience}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Domain Fit:</span>
                        <span className="text-white font-semibold">{res.scoreBreakdown.domainAlignment}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Soft Skills:</span>
                        <span className="text-white font-semibold">{res.scoreBreakdown.softSkillsLeadership}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Matched Skills */}
                  <div className="space-y-1.5 pt-3 border-t border-slate-800">
                    <span className="text-[11px] font-mono-code text-emerald-400 font-semibold uppercase">
                      Key Matched Skills ({res.matchedSkills.length})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {res.matchedSkills.slice(0, 6).map((sk, idx) => (
                        <span key={idx} className="text-[10px] bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 px-1.5 py-0.5 rounded font-mono-code">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Missing Crucial */}
                  <div className="space-y-1.5 pt-3 border-t border-slate-800">
                    <span className="text-[11px] font-mono-code text-rose-400 font-semibold uppercase">
                      Crucial Gaps ({res.missingCrucialSkills.length})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {res.missingCrucialSkills.map((sk, idx) => (
                        <span key={idx} className="text-[10px] bg-rose-950/60 border border-rose-800/40 text-rose-300 px-1.5 py-0.5 rounded font-mono-code">
                          {sk}
                        </span>
                      ))}
                      {res.missingCrucialSkills.length === 0 && (
                        <span className="text-[11px] text-emerald-400">None</span>
                      )}
                    </div>
                  </div>

                  {/* Executive Summary */}
                  <div className="pt-3 border-t border-slate-800 text-xs text-slate-300 leading-relaxed italic">
                    "{res.executiveSummary}"
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
};
