export interface ScoreBreakdown {
  technicalSkills: number;
  relevantExperience: number;
  educationCertifications: number;
  domainAlignment: number;
  softSkillsLeadership: number;
}

export interface InterviewQuestion {
  question: string;
  reason: string;
  expectedAnswerTheme: string;
}

export interface ScreeningResult {
  candidateName: string;
  candidateEmail?: string;
  candidatePhone?: string;
  candidateLocation?: string;
  currentRole?: string;
  totalExperienceYears?: number;
  educationSummary?: string;
  matchScore: number;
  scoreBreakdown: ScoreBreakdown;
  recommendation: 'Strong Hire' | 'Hire' | 'Consider' | 'Low Match' | 'Reject';
  executiveSummary: string;
  keyStrengths: string[];
  potentialGaps: string[];
  matchedSkills: string[];
  missingCrucialSkills: string[];
  niceToHaveSkillsPresent?: string[];
  redFlagsOrConcerns?: string[];
  customizedInterviewQuestions: InterviewQuestion[];
  recommendedSeniorityLevel?: string;
  applicantFeedbackTips?: string[];
}

export interface CandidateItem {
  id: string;
  name: string;
  fileName?: string;
  fileBase64?: string;
  mimeType?: string;
  resumeText: string;
  status: 'idle' | 'analyzing' | 'completed' | 'error';
  result?: ScreeningResult;
  error?: string;
  uploadedAt: string;
}

export interface JobTemplate {
  id: string;
  title: string;
  seniority: string;
  department: string;
  description: string;
  keySkills: string[];
}
