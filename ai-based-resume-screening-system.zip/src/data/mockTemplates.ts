import { JobTemplate, CandidateItem } from '../types';

export const DEFAULT_JOB_TEMPLATES: JobTemplate[] = [
  {
    id: 'fullstack-senior',
    title: 'Senior Full Stack Engineer (React / Node / Cloud)',
    seniority: 'Senior (5+ Years)',
    department: 'Engineering',
    keySkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'AWS', 'GraphQL', 'System Design'],
    description: `We are looking for a Senior Full Stack Engineer to lead architecture and development of our core web platform.

Key Responsibilities:
• Design, implement, and maintain responsive web applications using React, TypeScript, and modern state management.
• Build scalable backend microservices and RESTful / GraphQL APIs using Node.js and TypeScript.
• Architect relational database schemas in PostgreSQL, ensuring optimal indexing, query performance, and data integrity.
• Collaborate with Product & Design to translate complex business workflows into seamless user experiences.
• Drive engineering excellence: automated CI/CD pipelines, unit/integration testing (Jest, Cypress), and cloud deployment on AWS (ECS, RDS, S3).
• Mentor mid-level and junior engineers through thorough code reviews and architectural RFCs.

Must-Have Qualifications:
• 5+ years of production experience in web application development.
• Expert proficiency in TypeScript, React, and Node.js.
• Strong foundation in SQL and relational database modeling (PostgreSQL preferred).
• Proven track record architecting distributed systems or high-traffic web applications.
• Deep understanding of asynchronous programming, caching strategies (Redis), and API security.

Nice-to-Have:
• Experience with Docker containerization and Kubernetes.
• Familiarity with serverless architectures (AWS Lambda, Cloudflare Workers).
• Contributions to open-source software.`,
  },
  {
    id: 'ai-ml-engineer',
    title: 'Lead AI / Machine Learning Engineer (LLMs & RAG)',
    seniority: 'Lead / Staff (6+ Years)',
    department: 'AI & Data Science',
    keySkills: ['Python', 'PyTorch', 'Large Language Models (LLMs)', 'RAG', 'Vector Databases', 'LangChain', 'FastAPI', 'MLOps'],
    description: `Seeking a Lead AI/ML Engineer to spearhead our next-generation generative AI initiatives, agentic workflows, and semantic search systems.

Key Responsibilities:
• Lead research, fine-tuning, and deployment of foundation models and multimodal AI systems.
• Design production Retrieval-Augmented Generation (RAG) pipelines incorporating vector databases (Pinecone, Qdrant, Chroma).
• Build high-throughput inference APIs using FastAPI, Triton Inference Server, and Docker.
• Implement robust evaluation frameworks, guardrails, and telemetry for model hallucination detection and prompt optimization.
• Partner with infrastructure teams to establish automated MLOps pipelines on GCP or AWS.

Qualifications:
• 5+ years of practical ML engineering experience, with at least 2 years focused on Transformers and NLP/LLMs.
• Fluent in Python, PyTorch/TensorFlow, and modern GenAI ecosystems.
• Deep understanding of vector embeddings, indexing algorithms (HNSW), and hybrid search.
• MS or PhD in Computer Science, Data Science, or related field (or equivalent practical track record).`,
  },
  {
    id: 'product-manager',
    title: 'Senior Technical Product Manager (B2B SaaS)',
    seniority: 'Senior (4+ Years)',
    department: 'Product',
    keySkills: ['Product Strategy', 'B2B SaaS', 'Data Analytics', 'Agile/Scrum', 'API Products', 'User Research', 'SQL'],
    description: `We are hiring a Senior Technical Product Manager to own our developer platform and enterprise analytics product lines.

Key Responsibilities:
• Formulate product roadmaps based on customer feedback, market research, and competitive intelligence.
• Write comprehensive PRDs, user stories, and acceptance criteria for engineering sprints.
• Conduct user discovery interviews with enterprise CTOs and lead developers.
• Define and track key KPIs: MAU, net retention rate, customer churn, and API adoption.
• Work in close lockstep with Engineering Leads to prioritize technical debt against product feature delivery.

Requirements:
• 4+ years in product management at a B2B SaaS or developer tooling company.
• Strong technical background (ability to read API docs, write SQL queries, and understand cloud architecture).
• Exceptional written and verbal communication skills.`,
  },
];

export const SAMPLE_CANDIDATES: CandidateItem[] = [
  {
    id: 'sample-1',
    name: 'Alex Chen',
    uploadedAt: 'Today, 10:15 AM',
    status: 'completed',
    resumeText: `ALEX CHEN
San Francisco, CA | alex.chen.dev@example.com | (415) 555-0192 | github.com/alexchen-dev

SUMMARY:
Results-driven Senior Full Stack Engineer with 7+ years of experience designing, scaling, and maintaining mission-critical enterprise SaaS applications. Specialist in TypeScript, React, Node.js, and cloud architectures. Spearheaded migration of a monolithic platform to event-driven microservices serving 4.5M monthly active users.

CORE SKILLS:
Languages: TypeScript, JavaScript (ES6+), Python, SQL (PostgreSQL, MySQL), HTML5, CSS3/Tailwind
Frontend: React 19, Next.js, Redux Toolkit, Zustand, GraphQL (Apollo), WebSockets, Vite, Jest, Playwright
Backend & Cloud: Node.js, Express, NestJS, PostgreSQL, Redis, Docker, AWS (ECS, S3, RDS, CloudFront), Terraform
Methodologies: Agile/Scrum, CI/CD (GitHub Actions), System Architecture, Microservices, Security & Compliance

PROFESSIONAL EXPERIENCE:
Senior Full Stack Engineer | CloudScale Systems (2021 – Present)
• Architected scalable customer-facing web dashboard in React & TypeScript, slashing initial page load times by 48% via code-splitting and edge caching.
• Built high-performance Node.js REST and GraphQL microservices processing over 120,000 requests per minute with 99.98% uptime.
• Redesigned primary PostgreSQL database schema, partitioning tables and optimizing queries to reduce database latency by 35%.
• Spearheaded containerization with Docker and automated multi-stage CI/CD pipelines via GitHub Actions into AWS ECS.
• Mentored 4 mid-level and junior engineers; established organization-wide coding standards and TypeScript type safety guidelines.

Full Stack Software Engineer | Horizon Fintech (2018 – 2021)
• Developed responsive financial portfolio dashboard using React, Redux, and Node.js.
• Integrated secure payment gateways (Stripe, Plaid) compliant with PCI-DSS standards.
• Implemented real-time currency pricing feeds using WebSockets and Redis pub/sub.

EDUCATION:
B.S. in Computer Science | University of California, Berkeley (2014 – 2018)`,
    result: {
      candidateName: 'Alex Chen',
      candidateEmail: 'alex.chen.dev@example.com',
      candidatePhone: '(415) 555-0192',
      candidateLocation: 'San Francisco, CA',
      currentRole: 'Senior Full Stack Engineer',
      totalExperienceYears: 7,
      educationSummary: 'B.S. in Computer Science, UC Berkeley',
      matchScore: 94,
      scoreBreakdown: {
        technicalSkills: 96,
        relevantExperience: 94,
        educationCertifications: 92,
        domainAlignment: 95,
        softSkillsLeadership: 90,
      },
      recommendation: 'Strong Hire',
      executiveSummary: 'Outstanding senior candidate with exceptional alignment to core stack (React, TypeScript, Node.js, PostgreSQL, AWS). Demonstrated leadership scaling microservices to 4.5M MAU and actively mentoring team members.',
      keyStrengths: [
        'Exemplary command of modern TypeScript, React, and Node.js with production proof points.',
        'Hands-on experience architecting scalable distributed systems handling 120K req/min with PostgreSQL optimization.',
        'Strong cloud and DevOps acumen with Docker, AWS (ECS, RDS, S3), and GitHub Actions CI/CD.',
        'Demonstrated leadership through team mentorship and architectural RFC standard setting.',
      ],
      potentialGaps: [
        'Has not mentioned Kubernetes directly (uses AWS ECS and Docker).',
      ],
      matchedSkills: [
        'React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'AWS (ECS, RDS, S3)', 'GraphQL', 'System Design', 'Redis', 'CI/CD'
      ],
      missingCrucialSkills: [],
      niceToHaveSkillsPresent: ['Docker containerization', 'Redis caching', 'Mentorship experience', 'Microservices architecture'],
      redFlagsOrConcerns: [],
      customizedInterviewQuestions: [
        {
          question: 'In your PostgreSQL optimization at CloudScale, how did you decide on table partitioning strategies versus database sharding?',
          reason: 'Validates real-world database architecture depth and scalability limits.',
          expectedAnswerTheme: 'Discussion on query patterns, access keys, maintenance overhead, and trade-offs between horizontal vs vertical scaling.',
        },
        {
          question: 'Walk us through how you would architect an end-to-end event-driven workflow between your React frontend and Node backend when handling long-running asynchronous tasks.',
          reason: 'Verifies full-stack architectural cohesion and user feedback experience.',
          expectedAnswerTheme: 'Use of WebSockets/SSE or polling with Redis queue/worker pattern and optimistic UI updates.',
        },
      ],
      recommendedSeniorityLevel: 'Senior / Staff',
      applicantFeedbackTips: [
        'Highlight any experience with Kubernetes or serverless architectures (e.g. AWS Lambda) if applicable.',
        'Include specific metrics on team velocity improvements resulting from your mentorship.',
      ],
    },
  },
  {
    id: 'sample-2',
    name: 'Maya Patel',
    uploadedAt: 'Today, 11:00 AM',
    status: 'completed',
    resumeText: `MAYA PATEL
Austin, TX | maya.patel.ui@example.com | portfolio.mayapatel.design

SUMMARY:
Passionate Frontend Engineer with 5 years of experience crafting accessible, responsive, and pixel-perfect web interfaces. Deep expertise in React, Next.js, Tailwind CSS, WebGL/Three.js, and design systems. Transitioning toward full-stack development with recent Node.js and MongoDB personal projects.

SKILLS:
Frontend: React, Next.js, JavaScript, TypeScript, HTML5, CSS3, Tailwind CSS, Sass, Redux, Figma, Storybook, Jest
Backend (Basic): Node.js (Express), MongoDB, REST APIs
Tools: Git, Webpack, Vite, Vercel

EXPERIENCE:
Lead Frontend Developer | PixelCraft Studio (2021 – Present)
• Built reusable design systems in React and Tailwind used across 12 client products.
• Improved WCAG 2.1 AA accessibility compliance across flagship web application.
• Reduced client-side JavaScript bundle sizes by 32% using dynamic imports and asset tree-shaking.

Frontend Web Developer | NextWave Media (2019 – 2021)
• Created high-converting marketing landing pages with rich animations using Framer Motion.
• Built interactive data visual dashboards using React and D3.js.

EDUCATION:
B.A. in Interactive Media Design | UT Austin (2015 – 2019)`,
    result: {
      candidateName: 'Maya Patel',
      candidateEmail: 'maya.patel.ui@example.com',
      candidateLocation: 'Austin, TX',
      currentRole: 'Lead Frontend Developer',
      totalExperienceYears: 5,
      educationSummary: 'B.A. in Interactive Media Design, UT Austin',
      matchScore: 68,
      scoreBreakdown: {
        technicalSkills: 66,
        relevantExperience: 70,
        educationCertifications: 60,
        domainAlignment: 72,
        softSkillsLeadership: 78,
      },
      recommendation: 'Consider',
      executiveSummary: 'Superb frontend engineer with strong design system and React capabilities, but lacks required backend depth (Node.js microservices, PostgreSQL, AWS infrastructure) for a Senior Full Stack role.',
      keyStrengths: [
        'Outstanding React, TypeScript, and Tailwind design system expertise.',
        'Strong focus on web performance, bundle size optimization, and accessibility compliance (WCAG).',
        'Demonstrated leadership managing frontend design systems across multiple products.',
      ],
      potentialGaps: [
        'Limited backend production experience (only basic Express & MongoDB vs required enterprise PostgreSQL).',
        'No proven AWS cloud deployment or Docker containerization experience.',
        'Lacks distributed systems architecture background needed for a Senior Full Stack engineer.',
      ],
      matchedSkills: ['React', 'TypeScript', 'Node.js (basic)', 'Vite', 'REST APIs'],
      missingCrucialSkills: ['PostgreSQL', 'AWS / Cloud Architecture', 'Docker', 'GraphQL', 'System Design at Scale'],
      niceToHaveSkillsPresent: ['Design systems', 'Storybook', 'Framer Motion animations'],
      redFlagsOrConcerns: ['Applied for Senior Full Stack, but portfolio and achievements are almost exclusively frontend/UI.'],
      customizedInterviewQuestions: [
        {
          question: 'Can you describe a situation where you had to design or debug a backend API or complex database query?',
          reason: 'Determines whether candidate has practical backend exposure beyond introductory personal projects.',
          expectedAnswerTheme: 'Honest appraisal of backend scope, familiarity with HTTP status codes, data relationships, and async error handling.',
        },
      ],
      recommendedSeniorityLevel: 'Senior Frontend Engineer / Mid Full-Stack',
      applicantFeedbackTips: [
        'Consider applying specifically for Senior Frontend Engineer roles where your skills will rank in the top 5%.',
        'If targeting Full Stack, build and deploy end-to-end projects with PostgreSQL, relational joins, and cloud hosting.',
      ],
    },
  },
  {
    id: 'sample-3',
    name: 'David Kim',
    uploadedAt: 'Today, 11:20 AM',
    status: 'completed',
    resumeText: `DAVID KIM
Seattle, WA | dkim.coder@example.com

SUMMARY:
Motivated Junior Software Engineer and coding bootcamp graduate with 1.5 years of hands-on web development experience. Eager to contribute to collaborative engineering teams building modern React applications.

SKILLS:
JavaScript, React, Node.js, Express, HTML, CSS, Git, SQLite

PROJECTS:
TaskFlow - Team Project Manager (Full Stack)
• Built collaborative Kanban board using React and Express.
• Used SQLite for user accounts and task persistence.

RecipeFinder App
• Developed client-side React app fetching recipes from external third-party API.

EDUCATION:
Full Stack Web Development Certificate | CodeCrafters Bootcamp (2023)
B.S. in Biology | University of Washington (2022)`,
    result: {
      candidateName: 'David Kim',
      candidateEmail: 'dkim.coder@example.com',
      candidateLocation: 'Seattle, WA',
      currentRole: 'Junior Software Engineer',
      totalExperienceYears: 1.5,
      educationSummary: 'Full Stack Bootcamp Certificate / B.S. Biology',
      matchScore: 42,
      scoreBreakdown: {
        technicalSkills: 45,
        relevantExperience: 35,
        educationCertifications: 50,
        domainAlignment: 40,
        softSkillsLeadership: 55,
      },
      recommendation: 'Low Match',
      executiveSummary: 'Entry-level developer with strong enthusiasm and foundational React knowledge, but significantly underqualified for the Senior Full Stack role requiring 5+ years of distributed systems and cloud experience.',
      keyStrengths: [
        'Solid foundational grasp of core React and basic Express servers.',
        'High learning agility and proactive portfolio projects.',
      ],
      potentialGaps: [
        'Only 1.5 years experience vs 5+ years required.',
        'No production experience with TypeScript, PostgreSQL, AWS, Docker, or system design.',
      ],
      matchedSkills: ['React', 'Node.js'],
      missingCrucialSkills: ['TypeScript', 'PostgreSQL', 'Docker', 'AWS', 'System Design', 'CI/CD'],
      niceToHaveSkillsPresent: [],
      redFlagsOrConcerns: ['Mismatch in seniority level (Junior applicant for Senior role).'],
      customizedInterviewQuestions: [
        {
          question: 'How do you approach learning a new complex framework or debugging an issue when documentation is sparse?',
          reason: 'Assesses foundational problem-solving instincts.',
          expectedAnswerTheme: 'Structured debugging, reading source code, writing isolated tests.',
        },
      ],
      recommendedSeniorityLevel: 'Junior / Associate Developer',
      applicantFeedbackTips: [
        'Target Associate or Junior Developer positions to build foundational commercial experience.',
        'Incorporate TypeScript and relational databases (PostgreSQL) into your portfolio projects.',
      ],
    },
  },
  {
    id: 'sample-4',
    name: 'Elena Rostova',
    uploadedAt: 'Today, 11:45 AM',
    status: 'completed',
    resumeText: `ELENA ROSTOVA
New York, NY | elena.rostova@example.com | (212) 555-8391

SUMMARY:
Lead AI Engineer and System Architect with 8 years of experience building machine learning models, inference microservices, and high-performance computing pipelines in Python, C++, and Go. Deep background in large language models, RAG pipelines, and cloud deployment on AWS and GCP.

SKILLS:
Python, C++, Go, TypeScript (Intermediate), PyTorch, TensorFlow, Hugging Face, LangChain, Pinecone, Docker, Kubernetes, AWS, PostgreSQL, Redis, Kafka

EXPERIENCE:
Staff AI Engineer | Synthetix AI (2021 – Present)
• Led engineering team of 6 developing multi-tenant GenAI copilot backend in Python and FastAPI.
• Built low-latency RAG system with Pinecone and PostgreSQL pgvector, cutting latency from 1.2s to 180ms.
• Managed Kubernetes clusters on AWS EKS serving 10M daily model inference queries.

Senior Backend Engineer | DataStream Corp (2017 – 2021)
• Engineered distributed real-time data ingestion pipeline with Apache Kafka and Go.
• Optimized PostgreSQL and Redis data layer for financial time-series queries.

EDUCATION:
M.S. in Computer Science | Columbia University (2017)
B.S. in Applied Mathematics | NYU (2015)`,
    result: {
      candidateName: 'Elena Rostova',
      candidateEmail: 'elena.rostova@example.com',
      candidatePhone: '(212) 555-8391',
      candidateLocation: 'New York, NY',
      currentRole: 'Staff AI Engineer',
      totalExperienceYears: 8,
      educationSummary: 'M.S. Computer Science, Columbia University',
      matchScore: 78,
      scoreBreakdown: {
        technicalSkills: 80,
        relevantExperience: 82,
        educationCertifications: 95,
        domainAlignment: 68,
        softSkillsLeadership: 88,
      },
      recommendation: 'Consider',
      executiveSummary: 'Extremely talented Staff-level engineer with world-class backend, PostgreSQL, distributed systems, and AI architecture skills. While her frontend React experience is secondary, her system design and infrastructure depth are exceptional.',
      keyStrengths: [
        'Elite distributed systems and backend capabilities with PostgreSQL, Redis, Kafka, and Kubernetes.',
        'High-calibre education and proven architectural leadership managing 10M daily queries.',
        'Deep cloud (AWS EKS) and containerization mastery.',
      ],
      potentialGaps: [
        'Has intermediate TypeScript but little demonstrated production React frontend work.',
      ],
      matchedSkills: ['PostgreSQL', 'Docker', 'AWS', 'System Design', 'Redis', 'TypeScript (Intermediate)'],
      missingCrucialSkills: ['React (Advanced / Production UI)'],
      niceToHaveSkillsPresent: ['Kubernetes', 'High-throughput microservices', 'AI & RAG systems', 'Team leadership'],
      redFlagsOrConcerns: ['Might find a standard Full Stack role too heavily focused on UI rather than systems engineering.'],
      customizedInterviewQuestions: [
        {
          question: 'Given your deep AI and distributed backend background, how comfortable are you owning frontend React architectures and state management?',
          reason: 'Verifies willingness and readiness to work on browser client architecture.',
          expectedAnswerTheme: 'Interest in full-stack breadth or clarification on role responsibilities.',
        },
      ],
      recommendedSeniorityLevel: 'Staff Engineer / Principal Architect',
      applicantFeedbackTips: [
        'Would be a 98% match for Lead AI Engineer or Staff Distributed Systems roles.',
      ],
    },
  },
];
